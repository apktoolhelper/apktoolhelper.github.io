package kpa.plugin.myplugin;
import java.io.*;
import FormatFa.ApktoolHelper.*;
import kpa.plugin.library.*;

public class MyApp extends 我的插件
{

    @Override
    public void 插件信息()
    {
	我的插件.输出测试(this,"普通模式");
	//这里一般用于显示插件的基本介绍。

	//插件界面的帮助使用教程网址链接
	String 教程网址="http://www.baidu.com";
	我的插件.显示插件详情("这是我的插件。",教程网址);
	//*暂时不可使用插件自校检

    }


    @Override
    public void 单选文件操作(File 已选文件)
    {
	//文件列表中打开插件
	我的插件.输出测试(this,"单选模式");
	//*暂时不可使用插件自校检

    }


    @Override
    public void 多选文件操作(File[] 已选文件)
    {
	//多选文件方式打开插件
	我的插件.输出测试(this,"多选模式");
	//*暂时不可使用插件自校检

    }


    @Override
    public void APKTOOL工程(OpenApktoolProject KPA工程)
    {
	this.open=KPA工程;
	//反编译项目中打开插件
	我的插件.输出测试(this,"工程模式");

	//插件自校检示例
	我的插件.插件自校检(this,KPA工程);

    }


    @Override
    public void ZIP查看器(ZipReader ZIP)
    {
	this.zip=ZIP;
	//ZIP查看方式打开插件
	我的插件.输出测试(this,"压缩模式");

	//插件自校检示例
	//我的插件.插件自校检(this,ZIP);

	//颜色选择器控件
	//我的插件.颜色选择器(this);

	//一键植入操作示例
	String 插件名称="插件的名称";
	String 使用介绍="插件的使用方法";
	//插件界面的帮助使用教程网址链接
	String 教程网址="http://www.baidu.com";
	//植入到classes.dex的调用代码。
	String 调用代码="invoke-static {寄存器} Lcom/android/runtme/u;->a(Landroid/app/Activity;)V";
	//输入框可无限添加，不过建议10个内。
	String[] 输入框文字={"输入框1","输入框2","输入框3"};
	//用于替换plugin.dex内的指定字符串。
	String[] DEX关键字={"梦想飞翔","本地QQ","远程授权"};
	我的插件.自动化植入选择入口(ZIP,插件名称, 使用介绍, 调用代码, 教程网址, 输入框文字, DEX关键字);
    }



}

