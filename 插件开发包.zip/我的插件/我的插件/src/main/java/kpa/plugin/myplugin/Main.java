package kpa.plugin.myplugin;

import FormatFa.ApktoolHelper.*;
import FormatFa.ApktoolHelper.View.*;
import android.app.*;
import android.content.*;
import java.io.*;
import kpa.plugin.library.*;

public class Main extends 我的插件
{

    @Override
    public void 插件信息()
    {
	我的插件.输出测试(this, "普通模式");
	//这里一般用于显示插件的基本介绍。

	//插件界面的帮助使用教程网址链接
	String 教程网址="http://www.baidu.com";
	我的插件.显示插件详情("这是我的插件。", 教程网址);
	//*暂时不可使用插件自校检

    }


    @Override
    public void 单选文件操作(File 已选文件)
    {
	//文件列表中打开插件
	我的插件.输出测试(this, "单选模式");
	//*暂时不可使用插件自校检

    }


    @Override
    public void 多选文件操作(File[] 已选文件)
    {
	//多选文件方式打开插件
	我的插件.输出测试(this, "多选模式");
	//*暂时不可使用插件自校检

    }


    @Override
    public void APKTOOL工程(OpenApktoolProject KPA工程)
    {
	this.open = KPA工程;
	//反编译项目中打开插件
	我的插件.输出测试(this, "工程模式");

	//插件自校检示例
	//我的插件.插件自校检(this, KPA工程);

    }


    @Override
    public void ZIP查看器(final ZipReader ZIP)
    {
	this.zip = ZIP;
	//ZIP查看方式打开插件
	我的插件.输出测试(this, "压缩模式");

	//插件自校检示例
	//我的插件.插件自校检(this,ZIP)
	final String ApkPath = zip.getFile().getPath();
	我的插件.新线程(new 启动新线程(){
		@Override
		public void 线程开始(ThreadOperation root)
		{
		    我的插件.初始化插件(root, zip);
		}
		@Override
		public void 线程结束()
		{
		    if (!我的插件.判断是否为加固(zip))
		    {
			我的插件.输出测试(Main.this,"应用名称："+我的插件.获取应用名称((ApkPath))+
				  "\n应用包名："+我的插件.获取应用包名(ApkPath)+
				  "\n应用版本："+我的插件.获取版本号(ApkPath)+
				  "\n应用签名："+我的插件.获取应用签名(ApkPath)+
				  "\n应用大小："+我的插件.获取文件大小(ApkPath)+
				  "\n应用权限：\n"+我的插件.获取应用权限(ApkPath)+
				  "\n应用Activity：\n"+我的插件.获取应用Activity());
			主界面(ZIP, "彩色Toast弹窗2.0", "基于大佬火神之神的1.0牛逼版本", "http://www.baidu.com");
		    }
		}
	    });
    }

    public void 主界面(final ZipReader zip , String 插件名称 , final String 使用方法, final String 帮助教程网址链接)
    {
	final 滑动布局 滑动底布局 = new 滑动布局(上下文);
	final 线性布局 主线性布局 = new 线性布局(上下文);
	主线性布局.设置布局方向(垂直方向);
	主线性布局.设置布局内边距(自适应转换(24), 0, 自适应转换(24), 0);
	滑动底布局.添加布局(主线性布局);
	final 文本控件 文本控件 = new 文本控件(上下文);
	主线性布局.添加布局(文本控件);
	文本控件.设置文字颜色(红色);
	文本控件.设置文本内容("\n" + 使用方法 + "\n");
	final 输入框 文本输入框 = new 输入框(上下文);
	文本输入框.设置文本内容("填写Toast内容");
	我的插件.设置输入类型(文本输入框, "[ ]");
	主线性布局.添加布局(文本输入框);
	final 按钮控件 颜色选择按钮 = new 按钮控件(上下文);
	颜色选择按钮.设置文本内容("选择颜色");
	颜色选择按钮.设置点击事件(new 设置事件(){
		public void 点击事件()
		{
		    我的插件.颜色选择器(zip);
		}
	    });
	主线性布局.添加布局(颜色选择按钮);
	final 按钮控件 开始植入按钮 = new 按钮控件(上下文);
	开始植入按钮.设置文本内容("开始植入");
	主线性布局.添加布局(开始植入按钮);
	开始植入按钮.设置点击事件(new 设置事件(){
		public void 点击事件()
		{
		    if (颜色值 != 0 && !我的插件.判断输入框是否为空(文本输入框))
		    {
			String[] 植入菜单 = {"选择入口植入","只植入主入口","植入全部入口"};
			AlertDialog.Builder 植入选择列表 = new AlertDialog.Builder(zip);
			植入选择列表.setItems(植入菜单, new DialogInterface.OnClickListener() {
				@Override
				public void onClick(final DialogInterface dialog, final int which)
				{
				    final String 代码1="const-string v1 \"颜色值\"\nconst-string v2 \"信息\"\ninvoke-static {寄存器,v1,v2} Lcom/dofs/colortoast/ColorToast;->makeText(Landroid/content/Context;Ljava/lang/String;Ljava/lang/String;)V";
				    final String 代码2 = 我的插件.替换文本内容(代码1,"颜色值", 我的插件.颜色值转换("#", 颜色值));
				    final String 调用代码 = 我的插件.替换文本内容(代码2,"信息", 我的插件.获取输入框文字(文本输入框));
				    String[] 替换字={""};
				    String[] 关键字={""};
				    if (which == 0)
				    {
					我的插件.插件开始选择入口(zip, 调用代码, 关键字, 替换字);
				    }
				    else if (which == 1)
				    {
					我的插件.插件开始主入口(zip, 调用代码, 关键字, 替换字);
				    }
				    else if (which == 2)
				    {
					我的插件.插件开始全部入口(zip, 调用代码, 关键字, 替换字);
				    }
				}
			    });
			植入选择列表.show();
		    }
		    else
		    {
			我的插件.弹出提示弹窗("请填写内容并选择Toast颜色");
		    }
		}
	    });
	我的插件.设置插件布局(zip, 插件名称, 滑动底布局, 帮助教程网址链接);
    }

}
