package kpa.plugin.library;

import FormatFa.ApkEdit.*;
import FormatFa.ApktoolHelper.*;
import FormatFa.ApktoolHelper.Parser.*;
import FormatFa.ApktoolHelper.View.*;
import FormatFa.FDex.*;
import FormatFa.plugin.*;
import android.annotation.*;
import android.app.*;
import android.content.*;
import android.content.pm.*;
import android.graphics.*;
import android.graphics.drawable.*;
import android.net.*;
import android.os.*;
import android.telephony.*;
import android.text.*;
import android.view.*;
import android.view.View.*;
import android.webkit.*;
import android.widget.*;
import android.widget.LinearLayout.*;
import java.io.*;
import java.math.*;
import java.security.*;
import java.text.*;
import java.util.*;
import java.util.regex.*;
import javax.crypto.*;
import javax.crypto.spec.*;
import org.jf.dexlib.*;
import org.jf.dexlib.Code.*;
import org.jf.dexlib.Util.*;
import org.xmlpull.v1.*;
import android.content.pm.Signature;
import android.view.View.OnClickListener;
import android.view.View.OnLongClickListener;
import java.security.cert.*;

public abstract class 我的插件 extends PluginHelper
{
    private static String KEY="32F01926E9B44AA4009D3A15C4D19870",manifest="AndroidManifest.xml",dexname="classes.dex",plugin="plugin.dex",hexString="0123456789abcdef",start,jiagu,a9,a10,shuchu,d1,d2,code;
    private static TelephonyManager e;
    private static AlertDialog dialog,dialogs;
    private static InputStream resourse;
    private static File mani,decodedMani,dex;
    private static AndroidManifestRead read = null;
    private static EditText editview;
    private static ArrayList<EditText> items=new ArrayList<>();
    private static String[] chars,ite;
    private static List<String> clses;
    private static boolean needAdd=true;
    public static int 颜色值,垂直方向 = LinearLayout.VERTICAL,水平方向 = LinearLayout.HORIZONTAL;
    private static Key key;
    public static Context 上下文 = MyData.c;
    public static int 红色 = Color.RED;

    public static void 显示插件详情(String 插件简介, final String 帮助教程网址链接)
    {
	AlertDialog.Builder builders = new AlertDialog.Builder(getContext());
	builders.setCancelable(false);
	builders.setTitle("插件介绍");
	builders.setMessage(插件简介);
	builders.setPositiveButton("关闭", null);
	builders.setNegativeButton("", null);
	builders.setNeutralButton("使用说明", null);
	AlertDialog dialog = builders.show();
	dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener()
	    {
		@Override
		public void onClick(View v)
		{
		    显示帮助使用教程(帮助教程网址链接);
		}
	    });
    }

    public static void 新线程(ThreadOperation.OnStartListener OnStartListener)
    {
	new ThreadOperation(getContext(), "稍安勿躁", "正在启动,马上就好...").setOnStartListener(OnStartListener).start();
    }

    public static boolean 判断是否为加固(final ZipReader zip)
    {
	if (jiagu.equals("com.tencent.StubShell.TxAppEntry") == true || jiagu.equals("com.stub.StubApp") == true || jiagu.equals("kpa.dexprotect.DexApplication") == true || jiagu.equals("com.ali.mobisecenhance.ld.StubApplication") == true || jiagu.equals("s.h.e.l.l.S") == true || jiagu.equals("com.secshell.secData.ApplicationWrapper") == true || jiagu.equals("com.netease.nis.wrapper.MyApplication") == true)
	{
	    AlertDialog.Builder dg = new AlertDialog.Builder(getContext());
	    dg.setCancelable(false);
	    dg.setTitle("温馨提示");
	    dg.setMessage("当前APK可能已被加固，无法进行植入，请脱壳后再处理。");
	    dg.setNegativeButton("确定", new DialogInterface.OnClickListener(){
		    @Override
		    public void onClick(DialogInterface p1, int p2)
		    {
			zip.finish();
		    }
		});
	    dg.show();
	    return true;
	}
	return false;
    }

    public static String 获取输入框文字(EditText edittext)
    {
	return edittext.getText().toString();
    }

    public static String 替换文本内容(String 文字内容 , String 要替换的文字 , String 替换成什么)
    {
	return 文字内容.replace(要替换的文字, 替换成什么);
    }

    public static boolean 判断输入框是否为空(EditText edittext)
    {
	if (edittext.getText().toString() != null && edittext.getText().toString() != "" && edittext.getText().toString().length() != 0 && edittext.getText().toString().equals("") && !edittext.getText().toString().isEmpty() &&  !edittext.getText().toString().contains(" ") && edittext.getText().toString() != "null")
	{
	    return true;
	}
	return false;
    }

    public static void 颜色选择器(final ZipReader zip)
    {
	AlertDialog.Builder ColorDialog = new AlertDialog.Builder(getContext(), android.R.style.Theme_DeviceDefault_Light_Dialog_Alert);
	ColorDialog.setCancelable(false);
	ColorDialog.setTitle("请选取颜色：");
	final ColorPickerLayout picker = new ColorPickerLayout(getContext());
	ColorDialog.setView(picker);
	ColorDialog.setNegativeButton("取消", null);
	ColorDialog.setPositiveButton("确定", new DialogInterface.OnClickListener(){
		@Override
		public void onClick(DialogInterface p1, int p2)
		{
		    颜色值 = picker.getColor();
		    弹出提示弹窗("已选择颜色：" + 颜色值转换("#", 颜色值));
		}
	    });
	ColorDialog.show();
    }

    public static void 显示帮助使用教程(String 教程网址链接)
    {
	AlertDialog.Builder builder = new AlertDialog.Builder(getContext(), android.R.style.Theme_DeviceDefault_Light_Dialog_Alert);
	builder.setCancelable(false);
	builder.setTitle("使用说明");
        final WebView webview = new WebView(getContext());
	LayoutParams fn = new LayoutParams(LayoutParams.WRAP_CONTENT, LayoutParams.MATCH_PARENT);
	webview.setLayoutParams(fn);
	webview.loadUrl(教程网址链接);
	webview.setHorizontalScrollBarEnabled(false);
	webview.setVerticalScrollBarEnabled(false);
	webview.getSettings().setMixedContentMode(WebSettings.MIXED_CONTENT_ALWAYS_ALLOW);
	webview.getSettings().setUseWideViewPort(true);
	webview.getSettings().setLayoutAlgorithm(WebSettings.LayoutAlgorithm.NARROW_COLUMNS);
	webview.getSettings().setLoadWithOverviewMode(true);
	webview.getSettings().setBuiltInZoomControls(false);
	webview.getSettings().setSupportZoom(false);
	webview.setOverScrollMode(View.OVER_SCROLL_NEVER);
	webview.getSettings().setBlockNetworkImage(false);
	webview.setScrollContainer(false);
	webview.setVerticalScrollBarEnabled(false);
	webview.setHorizontalScrollBarEnabled(false);
	webview.getSettings().setAppCacheEnabled(true);
	webview.getSettings().setDatabaseEnabled(true);
	webview.getSettings().setDomStorageEnabled(true);
	webview.getSettings().setJavaScriptEnabled(true);
	webview.getSettings().setCacheMode(WebSettings.LOAD_DEFAULT);
	builder.setView(webview);
	builder.setNegativeButton("我知道了", null);
	dialogs = builder.create();
	final ProgressDialog progressdialog = new ProgressDialog(getContext());
	progressdialog.setMessage("请稍候....");
	progressdialog.setButton("关闭", new DialogInterface.OnClickListener(){
		@Override
		public void onClick(DialogInterface p1, int p2)
		{
		}
	    });
	progressdialog.show();
	webview.setWebViewClient(new WebViewClient() {
		@Override
		public boolean shouldOverrideUrlLoading(WebView webview, String url)
		{
		    webview.loadUrl(url);
		    return true;
		}
		@Override
		public void onReceivedError(WebView webview, int errorCode, String description, String failingUrl)
		{
		    super.onReceivedError(webview, errorCode, description, failingUrl);
		    dialogs.dismiss();
		}
		@Override
		public void onPageFinished(WebView webview, String url)
		{
		    super.onPageFinished(webview, url);
		    progressdialog.dismiss();
		    if (!dialogs.isShowing())
		    {
			dialogs.show();
		    }
		}
		@Override
		public void onPageStarted(WebView webview, String url, Bitmap favicon)
		{
		    super.onPageStarted(webview, url, favicon);
		    webview.loadUrl("javascript: var paras = document.getElementsByClassName('note-title-wrapper'); for(i=0;i<paras.length;i++){ if (paras[i] != null) paras[i].parentNode.removeChild( paras[i]);}");
		}
	    });
	webview.setOnLongClickListener(new OnLongClickListener() {
		@Override
		public boolean onLongClick(View view)
		{
		    return true;
		}
	    });
    }

    public static void 显示对话框(String 标题, String 信息, String 按钮一, String 按钮二, String 按钮三)
    {
	AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
	dialog.setCancelable(false);
	dialog.setTitle(标题);
	dialog.setMessage(信息);
	dialog.setPositiveButton(按钮三, null);
	dialog.setNegativeButton(按钮二, null);
	dialog.setNeutralButton(按钮一, null);
	dialog.show();
    }

    public static void 显示对话框(String 标题, String 信息, String 按钮一, String 按钮二)
    {
	AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
	dialog.setCancelable(false);
	dialog.setTitle(标题);
	dialog.setMessage(信息);
	dialog.setPositiveButton(按钮二, null);
	dialog.setNegativeButton(按钮一, null);
	dialog.show();
    }

    public static void 显示对话框(String 标题, String 信息, String 按钮一)
    {
	AlertDialog.Builder dialog = new AlertDialog.Builder(getContext());
	dialog.setCancelable(false);
	dialog.setTitle(标题);
	dialog.setMessage(信息);
	dialog.setPositiveButton(按钮一, null);
	dialog.show();
    }

    public static void 弹出提示弹窗(String 信息)
    {
	Toast.makeText(getContext(), 信息, Toast.LENGTH_LONG).show();
    }

    public static void 输出测试(我的插件 main , String 信息)
    {
	try
	{
	    InputStream My = main.getResourse(d(KEY, "C0287D298E96601146D45BF5FFB5DB6F"));
	    if (My != null)
	    {
		Toast.makeText(getContext(), 信息, Toast.LENGTH_SHORT).show();
	    }
	    else
	    {}
	}
	catch (IOException e)
	{}
    }

    private static TelephonyManager d()
    {
	if (e == null)
	{  
	    e = (TelephonyManager) getContext().getSystemService(Context.TELEPHONY_SERVICE);  
	}  
	return e;  
    }

    public static String 获取唯一识别码(Context getContext)
    {  
	String bk = d().getDeviceId();
	return bk;  
    }

    public static int 自适应转换(double 数字)
    {
	final float scale = getContext().getResources().getDisplayMetrics().density;
	return (int) (数字 * scale + 0.5f);
    }

    private static String c(String m , String p)
    {
	try
	{
	    a9 = a(m, p);
	}
	catch (Exception e)
	{}
	return a9;
    }

    private static String d(String m , String p)
    {
	try
	{
	    a10 = b(m, p);
	}
	catch (Exception e)
	{}
	return a10;
    }

    private static String a(String m, String p)throws Exception
    {  
	byte[] dg = a(m.getBytes());  
	byte[] dh = a(dg, p.getBytes());  
	return b(dh);  
    }  

    private static String b(String m, String p)throws Exception
    {  
	byte[] dg = a(m.getBytes());  
	byte[] di = a(p);  
	byte[] dh = b(dg, di);  
	return new String(dh);
    }  

    @SuppressLint("TrulyRandom")  
    private static byte[] a(byte[] s)throws Exception
    {  
	KeyGenerator dj = KeyGenerator.getInstance("AES");  
	SecureRandom dk = SecureRandom.getInstance("SHA1PRNG", "Crypto");  
	dk.setSeed(s);  
	dj.init(128, dk);
	SecretKey dl = dj.generateKey();  
	byte[] dm = dl.getEncoded();  
	return dm;  
    }  

    private static byte[] a(byte[] s, byte[] t) throws Exception
    {  
	SecretKeySpec dn = new SecretKeySpec(s, "AES");  
	Cipher dp = Cipher.getInstance("AES");  
	dp.init(Cipher.ENCRYPT_MODE, dn, new IvParameterSpec(new byte[dp.getBlockSize()]));  
	byte[] dq = dp.doFinal(t);  
	return dq;  
    }  

    private static byte[] b(byte[] s, byte[] t)throws Exception
    {  
	SecretKeySpec dn = new SecretKeySpec(s, "AES");  
	Cipher dp = Cipher.getInstance("AES");  
	dp.init(Cipher.DECRYPT_MODE, dn, new IvParameterSpec(new byte[dp.getBlockSize()]));  
	byte[] dr = dp.doFinal(t);  
	return dr;  
    }  

    private static byte[] a(String m)
    {  
	int ds = m.length() / 2;  
	byte[] dh = new byte[ds];  
	for (int i = 0; i < ds; i++)  
	    dh[i] = Integer.valueOf(m.substring(2 * i, 2 * i + 2), 16).byteValue();  
	return dh;  
    }  

    private static String b(byte[] s)
    {  
	if (s == null)  
	    return "";  
	StringBuffer dh = new StringBuffer(2 * s.length);  
	for (int i = 0; i < s.length; i++)
	{  
	    a(dh, s[i]);  
	}
	return dh.toString();  
    }  

    private static void a(StringBuffer u, byte v)
    {
	u.append("0123456789ABCDEF".charAt((v >> 4) & 0x0f)).append("0123456789ABCDEF".charAt(v & 0x0f));  
    }

    private static byte[] getFileAsByte(String name)
    {
	return b(b(name));
    }

    private static InputStream b(String name)
    {
	return 我的插件.class.getResourceAsStream((name));
    }

    private static byte[] b(InputStream is)
    {
	ByteArrayOutputStream byo = new ByteArrayOutputStream();
	try
	{
	    a(is, byo);
	}
	catch (IOException e)
	{}
	return byo.toByteArray();
    }

    private static boolean a(InputStream is, OutputStream os) throws IOException
    {
	if (is == null)return false;
	byte[] buff = new byte[1024 * 4];
	int leng=0;
	while ((leng = is.read(buff)) != -1)
	{
	    os.write(buff, 0, leng);
	}
	os.flush();
	os.close();
	return true;
    }

    private static String a(InputStream in)
    {
	MessageDigest digest = null;
	byte buffer[] = new byte[1024];
	int len;
	try
	{
	    digest = MessageDigest.getInstance("MD5");
	    while ((len = in.read(buffer, 0, 1024)) != -1)
	    {
		digest.update(buffer, 0, len);
	    }
	    in.close();
	}
	catch (Exception e)
	{
	    e.printStackTrace();
	    return null;
	}
	BigInteger bigInt = new BigInteger(1, digest.digest());
	return bigInt.toString(16);
    }

    public static String 获取文件MD5(InputStream in)
    {
	return a(in);
    }

    public static String 字符加密(String 内容) 
    { 
	byte[] bytes=内容.getBytes(); 
	StringBuilder sb=new StringBuilder(bytes.length * 2); 
	for (int i=0;i < bytes.length;i++) 
	{ 
	    sb.append(hexString.charAt((bytes[i] & 0xf0) >> 4)); 
	    sb.append(hexString.charAt((bytes[i] & 0x0f) >> 0)); 
	} 
	String st1="";
	String rreg[] ={"a","b","c","d","e","f","0","1","2","3","4","5","6","7","8","9"};
	String rre[] = {".",":","+","}","?","$","……","%","_","～","&","#","•",">","、","￥"};
	for (int a=0;a < 16;a++)
	{
	    if (a == 0)
	    {
		st1 = sb.toString().replace(rreg[a], rre[a]);
	    }
	    st1 = st1.replace(rreg[a], rre[a]);
	}
	return st1; 
    } 

    public static String 字幕解密(String 内容) 
    { 
	String bytes="";
	String rreg[] ={"a","b","c","d","e","f","0","1","2","3","4","5","6","7","8","9"};
	String rre[] = {".",":","+","}","?","$","……","%","_","～","&","#","•",">","、","￥"};
	for (int a=0;a < 16;a++)
	{
	    if (a == 0)
	    {
		bytes = 内容.replace(rre[a], rreg[a]);
	    }
	    bytes = bytes.replace(rre[a], rreg[a]);
	}
	ByteArrayOutputStream baos=new ByteArrayOutputStream(bytes.length() / 2); 
	for (int i=0;i < bytes.length();i += 2) 
	    baos.write((hexString.indexOf(bytes.charAt(i)) << 4 | hexString.indexOf(bytes.charAt(i + 1)))); 
	return new String(baos.toByteArray()); 
    }

    public void 加密文件(String 需要加密的路径, String 加密后的路径) throws Exception
    { 
	加密后的路径 = 加密后的路径 + ".xv";
	Cipher cipher = Cipher.getInstance("DES"); 
	// cipher.init(Cipher.ENCRYPT_MODE, getKey()); 
	cipher.init(Cipher.ENCRYPT_MODE, this.key); 
	InputStream is = new FileInputStream(需要加密的路径); 
	OutputStream out = new FileOutputStream(加密后的路径); 
	CipherInputStream cis = new CipherInputStream(is, cipher); 
	byte[] buffer = new byte[1024]; 
	int r; 
	while ((r = cis.read(buffer)) > 0)
	{ 
	    out.write(buffer, 0, r); 
	} 
	cis.close(); 
	is.close(); 
	out.close(); 
    } 

    public void 解密文件(String 需要解密的路径, String 解密后的路径) throws Exception
    { 
	解密后的路径 = 解密后的路径 + ".xv";
	Cipher cipher = Cipher.getInstance("DES"); 
	cipher.init(Cipher.DECRYPT_MODE, this.key); 
	InputStream is = new FileInputStream(需要解密的路径); 
	OutputStream out = new FileOutputStream(解密后的路径); 
	CipherOutputStream cos = new CipherOutputStream(out, cipher); 
	byte[] buffer = new byte[1024]; 
	int r; 
	while ((r = is.read(buffer)) >= 0)
	{ 
	    System.out.println();
	    cos.write(buffer, 0, r); 
	} 
	cos.close(); 
	out.close(); 
	is.close(); 
    } 

    public static void 创建文件(String 文件名称, String 写入数据)
    {
	String filePath = null;
	boolean hasSDCard =Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
	if (hasSDCard)
	{
            filePath = Environment.getExternalStorageDirectory().toString() + File.separator + 文件名称;
	}
	else
	    Toast.makeText(getContext(), "没有储存读写权限。", Toast.LENGTH_LONG).show();
	try
	{
            File file = new File(filePath);
            if (!file.exists())
	    {
                File dir = new File(file.getParent());
                dir.mkdirs();
                file.createNewFile();
            }
            FileOutputStream outStream = new FileOutputStream(file);
            outStream.write(写入数据.getBytes());
            outStream.close();
	}
	catch (Exception e)
	{
            e.printStackTrace();
	}
    }

    private static Context getContext()
    {
        return MyData.c;
    }

    @Override
    public void execute()
    {
	插件信息();
    }

    @Override
    public void ASFile(final File file)
    {
	单选文件操作(file);
    }

    @Override
    public void MulitASFile(final File[] file)
    {
	多选文件操作(file);
    }

    @Override
    public void onApktoolProject(final OpenApktoolProject open)
    {
	APKTOOL工程(open);
    }

    @Override
    public void onZipReader(final ZipReader zip)
    {
	ZIP查看器(zip);
    }

    public abstract void 插件信息();

    public abstract void 单选文件操作(final File 已选文件);

    public abstract void 多选文件操作(final File[] 已选文件);

    public abstract void APKTOOL工程(final OpenApktoolProject KPA工程);

    public abstract void ZIP查看器(final ZipReader ZIP);

    public static InputStream 获取文件流(我的插件 main, String 文件名称)
    {
	try
	{
	    resourse = main.getResourse(文件名称);
	}
	catch (IOException e)
	{}
	return resourse;
    }

    public static String 颜色值转换(String 格式, int 颜色)
    {
	return String.format(格式 + "%08X", Integer.valueOf(颜色));
    }

    public static String 读取文本(InputStream 文件流, String 分隔符, int 位置)
    {
	try
	{
	    InputStreamReader read = new InputStreamReader(文件流, "UTF-8");
	    BufferedReader bufferedReader = new BufferedReader(read);
	    String lineTxt = null;
	    String[] singleString = null;
	    while ((lineTxt = bufferedReader.readLine()) != null)
	    {
		singleString = lineTxt.split(分隔符);
		shuchu = singleString[位置];
	    }
	    read.close();
	}
	catch (IOException e)
	{}
	return shuchu;
    }

    public static void 插件开始主入口(final ZipReader zip , final String 调用代码, final String... 关键字, final String... 替换文字)
    {
	new ThreadOperation(getContext(), "请稍候", "正在处理中...").setOnStartListener(new ThreadOperation.OnStartListener(){
		@Override
		public void start(ThreadOperation root)
		{
		    代码植入主入口(root, zip, 调用代码, 关键字, 替换文字);
		}
		@Override
		public void finish()
		{
		    插件结束并保存(zip, null);
		}
	    }).start();
    }

    public static void 插件开始全部入口(final ZipReader zip , final String 调用代码, final String... 关键字, final String... 替换文字)
    {
	new ThreadOperation(getContext(), "请稍候", "正在处理中...").setOnStartListener(new ThreadOperation.OnStartListener(){
		@Override
		public void start(ThreadOperation root)
		{
		    代码植入全部入口(root, zip, 调用代码, 关键字, 替换文字);
		}
		@Override
		public void finish()
		{
		    插件结束并保存(zip, null);
		}
	    }).start();
    }

    public static void 插件开始选择入口(final ZipReader zip, final String 调用代码, final String... 关键字, final String... 替换文字)
    {
	AlertDialog.Builder listDialog = new AlertDialog.Builder(zip);
	listDialog.setCancelable(false);
	listDialog.setTitle("请选择入口");
	listDialog.setItems(ite, new DialogInterface.OnClickListener() {
		@Override
		public void onClick(final DialogInterface dialog, final int which)
		{
		    new ThreadOperation(getContext(), "请稍候", "正在处理中...").setOnStartListener(new ThreadOperation.OnStartListener(){
			    @Override
			    public void start(ThreadOperation root)
			    {
				代码植入选择入口(root, zip, ite[which], 调用代码, 关键字, 替换文字);
				needAdd = false;
			    }
			    @Override
			    public void finish()
			    {
				if (needAdd == true)
				{
				    MyData.SimpleDialog("植入失败", "发生了未知错误。");
				}
				else
				{
				    插件结束并保存(zip, null);
				}
			    }
			}).start();
		}
	    });
	listDialog.setPositiveButton("取消", new DialogInterface.OnClickListener(){
		@Override
		public void onClick(DialogInterface p1, int p2)
		{
		    dialog.show();
		}
	    });
	listDialog.show();
	dialog.dismiss();

    }

    public static void 插件结束并保存(final ZipReader zip, final String 保存提示内容)
    {
	ZipReplace[] res = new ZipReplace[2];
	res[0] = new ZipReplace(ZipReplace.REPLACE, manifest, mani.getAbsolutePath());
	res[1] = new ZipReplace(ZipReplace.REPLACE, dexname, dex.getAbsolutePath());
	zip.getOperation().setReplace(res);
	dialog.dismiss();
	if (保存提示内容 != null && 保存提示内容 != "" && 保存提示内容.length() != 0)
	{
	    zip.save("APK软件安装包已处理，未进行签名；\n请手动修改重命名后点击保存。\n" + 保存提示内容, false);
	}
	else
	{
	    zip.save("APK软件安装包已处理，未进行签名；\n请手动修改重命名后点击保存。", false);
	}
	Toast.makeText(getContext(), "代码植入已完成，请手动修改文件名称", 0).show();
    }

    public static void 自动化植入主入口(final ZipReader zip, final String 插件名称, final String 使用方法, final String 调用代码, final String 帮助教程网址链接, final String... 输入框, final String... 关键字)
    {
	new ThreadOperation(getContext(), "稍安勿躁", "正在启动,马上就好...").setOnStartListener(new ThreadOperation.OnStartListener(){
		@Override
		public void start(ThreadOperation root)
		{
		    初始化插件(root, zip);
		}
		@Override
		public void finish()
		{
		    if (!判断是否为加固(zip))
		    {
			插件植入主入口(zip, 插件名称, 使用方法, 调用代码, 帮助教程网址链接, 输入框, 关键字);
		    }
		}
	    }).start();
    }

    public static void 自动化植入全部入口(final ZipReader zip, final String 插件名称, final String 使用方法, final String 调用代码, final String 帮助教程网址链接, final String... 输入框, final String... 关键字)
    {
	new ThreadOperation(getContext(), "稍安勿躁", "正在启动,马上就好...").setOnStartListener(new ThreadOperation.OnStartListener(){
		@Override
		public void start(ThreadOperation root)
		{
		    初始化插件(root, zip);
		}
		@Override
		public void finish()
		{
		    if (!判断是否为加固(zip))
		    {
			插件植入全部入口(zip, 插件名称, 使用方法, 调用代码, 帮助教程网址链接, 输入框, 关键字);
		    }
		}
	    }).start();
    }

    public static void 自动化植入选择入口(final ZipReader zip, final String 插件名称, final String 使用方法, final String 调用代码, final String 帮助教程网址链接, final String... 输入框, final String... 关键字)
    {
	new ThreadOperation(getContext(), "稍安勿躁", "正在启动,马上就好...").setOnStartListener(new ThreadOperation.OnStartListener(){
		@Override
		public void start(ThreadOperation root)
		{
		    初始化插件(root, zip);
		}
		@Override
		public void finish()
		{
		    if (!判断是否为加固(zip))
		    {
			插件植入选择入口(zip, 插件名称, 使用方法, 调用代码, 帮助教程网址链接, 输入框, 关键字);
		    }
		}
	    }).start();
    }

    public static void 插件植入全部入口(final ZipReader zip , String 插件名称 , final String 使用方法 , final String 调用代码, final String 帮助教程网址链接, final String... 输入框, final String... 关键字)
    {
	final ScrollView scrollview = new ScrollView(getContext());
	final LinearLayout layout = new LinearLayout(getContext());
	layout.setOrientation(layout.VERTICAL);
	layout.setPadding(自适应转换(24), 0, 自适应转换(24), 0);
	scrollview.addView(layout);
	final TextView textview = new TextView(getContext());
	layout.addView(textview);
	textview.setTextColor(Color.RED);
	textview.setText("\n" + 使用方法 + "\n");
	for (String edit:输入框)
	{
	    editview = new EditText(getContext());
	    editview.setText(edit);
	    设置输入类型(editview, "[ ]");
	    layout.addView(editview);
	    items.add(editview);
	}
	final Button button = new Button(getContext());
	button.setText("开始植入");
	layout.addView(button);
	button.setOnClickListener(new OnClickListener(){
		@Override
		public void onClick(View p1)
		{
		    StringBuilder sb = new StringBuilder();
		    for (EditText item:items)
		    {
			sb.append(item.getText().toString().trim()).append(",");
			chars = sb.toString().split(",");
		    }
		    if (!判断输入框是否为空(editview))
		    {
			插件开始全部入口(zip, 调用代码, 关键字, chars);
		    }
		    else
		    {
			Toast.makeText(getContext(), "请填写完整。", 0).show();
		    }
		}
	    });
	设置插件布局(zip, 插件名称, scrollview, 帮助教程网址链接);
    }

    public static void 插件植入主入口(final ZipReader zip , String 插件名称 , final String 使用方法 , final String 调用代码, final String 帮助教程网址链接, final String... 输入框, final String... 关键字)
    {
	final ScrollView scrollview = new ScrollView(getContext());
	final LinearLayout layout = new LinearLayout(getContext());
	layout.setOrientation(layout.VERTICAL);
	layout.setPadding(自适应转换(24), 0, 自适应转换(24), 0);
	scrollview.addView(layout);
	final TextView textview = new TextView(getContext());
	layout.addView(textview);
	textview.setTextColor(Color.RED);
	textview.setText("\n" + 使用方法 + "\n");
	for (String edit:输入框)
	{
	    editview = new EditText(getContext());
	    editview.setText(edit);
	    设置输入类型(editview, "[ ]");
	    layout.addView(editview);
	    items.add(editview);
	}
	final Button button = new Button(getContext());
	button.setText("开始植入");
	layout.addView(button);
	button.setOnClickListener(new OnClickListener(){
		@Override
		public void onClick(View p1)
		{
		    StringBuilder sb = new StringBuilder();
		    for (EditText item:items)
		    {
			sb.append(item.getText().toString().trim()).append(",");
			chars = sb.toString().split(",");
		    }
		    if (!判断输入框是否为空(editview))
		    {

			插件开始主入口(zip, 调用代码, 关键字, chars);
		    }
		    else
		    {
			Toast.makeText(getContext(), "请填写完整。", 0).show();
		    }
		}
	    });
	设置插件布局(zip, 插件名称, scrollview, 帮助教程网址链接);
    }

    public static void 插件植入选择入口(final ZipReader zip , String 插件名称 , final String 使用方法 , final String 调用代码, final String 帮助教程网址链接, final String... 输入框, final String... 关键字)
    {
	final ScrollView scrollview = new ScrollView(getContext());
	final LinearLayout layout = new LinearLayout(getContext());
	layout.setOrientation(layout.VERTICAL);
	layout.setPadding(自适应转换(24), 0, 自适应转换(24), 0);
	scrollview.addView(layout);
	final TextView textview = new TextView(getContext());
	layout.addView(textview);
	textview.setTextColor(Color.RED);
	textview.setText("\n" + 使用方法 + "\n");
	for (String edit:输入框)
	{
	    editview = new EditText(getContext());
	    editview.setText(edit);
	    设置输入类型(editview, "[ ]");
	    layout.addView(editview);
	    items.add(editview);
	}
	final Button button = new Button(getContext());
	button.setText("开始植入");
	layout.addView(button);
	button.setOnClickListener(new OnClickListener(){
		@Override
		public void onClick(View p1)
		{
		    StringBuilder sb = new StringBuilder();
		    for (EditText item:items)
		    {
			sb.append(item.getText().toString().trim()).append(",");
			chars = sb.toString().split(",");
		    }
		    if (!判断输入框是否为空(editview))
		    {
			插件开始选择入口(zip, 调用代码, 关键字, chars);
		    }
		    else
		    {
			Toast.makeText(getContext(), "请填写完整。", 0).show();
		    }
		}
	    });
	设置插件布局(zip, 插件名称, scrollview, 帮助教程网址链接);
    }

    public static void 设置插件布局(final ZipReader zip , String 插件名称 , View scrollview , final String 帮助教程网址链接)
    {
	AlertDialog.Builder builder = new AlertDialog.Builder(getContext());
	builder.setCancelable(false);
	builder.setTitle(插件名称);
	builder.setView(scrollview);
	builder.setNegativeButton("退出", null);
	builder.setNeutralButton("使用说明", null);
	dialog = builder.show();
	dialog.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener()
	    {
		@Override
		public void onClick(View v)
		{
		    zip.finish();
		}
	    });
	dialog.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener()
	    {
		@Override
		public void onClick(View v)
		{
		    显示帮助使用教程(帮助教程网址链接);
		}
	    });
    }

    public static void 初始化插件(ThreadOperation root, ZipReader zip)
    {
	root.sendMsg("正在处理,请稍候...");
	mani = new File(getContext().getFilesDir(), manifest);
	decodedMani = new File(mani.getAbsolutePath() + ".xml");
	dex = new File(getContext().getFilesDir(), dexname);
	if (!zip.getOperation().jieyaItem("AndroidManifest.xml", mani.getParentFile()) || !zip.getOperation().jieyaItem(dexname, dex.getParentFile()))
	{
	    root.finishWithResult("Dex文件处理失败\n该Apk软件的classes.dex可能已加密或损坏。");
	    return;
	}
	try
	{
	    com.bigzhao.xml2axml.test.Main.decode(mani.getAbsolutePath(), decodedMani.getAbsolutePath());
	}
	catch (FileNotFoundException e)
	{
	    root.finishWithResult("出现错误：\n" + e.toString());
	    return;
	}
	try
	{
	    read = new AndroidManifestRead(decodedMani);
//	    read.addPermission("android.permission.INTERNET");
//	    read.addPermission("android.permission.ACCESS_NETWORK_STATE");
//	    read.addPermission("android.permission.ACCESS_WIFI_STATE");
//	    read.addPermission("android.permission.CHANGE_NETWORK_STATE");
//	    read.addPermission("android.permission.CHANGE_WIFI_STATE");
//	    read.addPermission("android.permission.READ_PHONE_STATE");
	    jiagu = read.getApplicationName();
	    read.Save();
	}
	catch (Exception e)
	{
	    root.finishWithResult("这可能并不是一个完整的安卓APK软件安装包\n" + e.toString());
	    return;
	}
	root.sendMsg("解析APK包中...");
	if (read == null || read.getFirstActivityName() == null)
	{
	    root.finishWithResult("读取AndroidManifest失败\n该Apk软件的AndroidManifest.xml可能存在未知属性,加密或损坏。");
	    return;
	}
	if (read.getFirstActivityName().equals("com.androlua.Welcome") == true)
	{
	    start = "com.androlua.Main";
	}
	else if (read.getFirstActivityName().equals("com.e4a.runtime.android.StartActivity") == true)
	{
	    start = "com.e4a.runtime.android.mainActivity";
	}
	else if (read.getFirstActivityName().equals("com.iapp.app.logoActivity") == true)
	{
	    start = "com.iapp.app.run.mian";
	}
	else
	{
	    start = read.getFirstActivityName();
	}
	if (start.startsWith("."))
	{
	    start = read.getPackage() + start;
	}
	root.sendMsg("正在获取启动项...");
	PackageManager pm = getContext().getPackageManager();
	final PackageInfo info = pm.getPackageArchiveInfo(zip.getFile().getAbsolutePath(), pm.GET_ACTIVITIES);
	ActivityInfo[] as = info.activities;
	clses = new ArrayList<String>();
	root.sendMsg("获取程序入口中...");
	for (ActivityInfo a:as)
	{
	    if (a.name.startsWith("."))
		clses.add(info.packageName + a.name);
	    else
		clses.add(a.name);
	}
	StringBuilder it = new StringBuilder();
	for (String item:clses)
	{
	    it.append(item.toString().trim()).append(",");
	    ite = it.toString().split(",");
	}
	root.sendMsg("请稍候...");
    }

    public static void 代码植入主入口(final ThreadOperation root, ZipReader zip, String 调用代码 , final String... DEX关键字 , final String... 替换文字)
    {
	try
	{
	    只主入口(root, zip, 调用代码, DEX关键字, 替换文字);
	}
	catch (IOException e)
	{
	    root.finishWithResult("出现错误：\n" + e.toString());
	}
	catch (XmlPullParserException e)
	{
	    root.finishWithResult("出现错误：\n" + e.toString());
	}
    }

    public static void 代码植入全部入口(final ThreadOperation root, ZipReader zip, String 调用代码 , final String... DEX关键字 , final String... 替换文字)
    {
	try
	{
	    全部入口(root, zip, 调用代码, DEX关键字, 替换文字);
	}
	catch (IOException e)
	{
	    root.finishWithResult("出现错误：\n" + e.toString());
	}
	catch (XmlPullParserException e)
	{
	    root.finishWithResult("出现错误：\n" + e.toString());
	}
    }

    public static void 代码植入选择入口(final ThreadOperation root, final ZipReader zip, String itm, final String 调用代码 , final String... DEX关键字 , final String... 替换文字)
    {
	try
	{
	    选择入口(root, zip, itm, 调用代码, DEX关键字, 替换文字);
	}
	catch (IOException e)
	{
	    root.finishWithResult("出现错误：\n" + e.toString());
	}
	catch (XmlPullParserException e)
	{
	    root.finishWithResult("出现错误：\n" + e.toString());
	}
    }

    private static void 只主入口(final ThreadOperation root, ZipReader zip, String 调用代码 , final String... DEX关键字 , final String... 替换文字) throws IOException, XmlPullParserException
    {
	try
	{
	    root.sendMsg("开始处理...");
//	if (start.equals("com.iapp.app.run.mian") != true)
//	{
	    String rawXml=FormatFaUtils.sdtoString(decodedMani.getAbsolutePath());
	    String beAdded =new String(getFileAsByte("/AndroidManifes"));
	    String[] beAddeds = beAdded.split("<!--添加所需要的权限配置\\(勿删\\)-->");
	    String beAddes = beAddeds[0];
	    String beAddesd = beAddeds[1];
	    String rawXmls = rawXml.replace("</application>", beAddes + "</application>");
	    String rawXms = rawXmls.replace("</manifest>", beAddesd + "</manifest>");
	    root.sendMsg("正在植入权限...");
	    FormatFaUtils.stringtosd(rawXms, decodedMani.getAbsolutePath());
	    root.sendMsg("正在植入权限...");
	    com.bigzhao.xml2axml.test.Main.encode(getContext(), decodedMani.getAbsolutePath(), mani.getAbsolutePath());
//	}
//	else
//	{
//	    Handler handler = new Handler(Looper.getMainLooper());
//	    handler.post(new Runnable() {
//		    @Override
//		    public void run()
//		    {
//			final ClipboardManager cm = (ClipboardManager)zip.getSystemService(Context.CLIPBOARD_SERVICE);
//			AlertDialog.Builder builders = new AlertDialog.Builder(getContext());
//			builders.setCancelable(false);
//			builders.setTitle("当前Apk为iAPP软件");
//			final String manifes = new String(WeiyunUnits.getFileAsByte("/AndroidManifes"));
//			final String permission = new String(WeiyunUnits.getFileAsByte("/AndroidPermission"));
//			builders.setMessage("请点击下方的按钮进行复制\n把复制的Activity清单和权限信息粘贴到已经植入完的APK里的AndroidManifes.xml里\n植入完Apk的名字是你改的，你应该知道。可使用MT管理器或者其他工具。");
//			builders.setPositiveButton("关闭", null);
//			builders.setNegativeButton("复制清单", null);
//			builders.setNeutralButton("复制权限", null);
//			AlertDialog dialogs = builders.create();
//			dialogs.show();
//			dialogs.getButton(AlertDialog.BUTTON_NEGATIVE).setOnClickListener(new View.OnClickListener()
//			    {
//				@Override
//				public void onClick(View v)
//				{
//				    cm.setText(manifes);
//				    Toast.makeText(getContext(), "Activity清单配置信息已复制，长按即可粘贴。", 0).show();
//				}
//			    });
//			dialogs.getButton(AlertDialog.BUTTON_NEUTRAL).setOnClickListener(new View.OnClickListener()
//			    {
//				@Override
//				public void onClick(View v)
//				{
//				    cm.setText(permission);
//				    Toast.makeText(getContext(), "权限配置信息已经复制，长按即可粘贴。", 0).show();
//				}
//			    });
//		    }
//		});
//	}
	    root.sendMsg("请稍候,正在处理中...");
	    DexUtils sharedex;
	    sharedex = new DexUtils(new DexFile(getFileAsByte("/plugin.dex")));
	    DexUtils apkDex ;
	    apkDex = new DexUtils(new DexFile(FileUtils.readFile(dex)));
	    root.sendMsg("处理Dex文件中...");
	    sharedex.StringReplace("启动界面", start);
	    final int i;
	    int ii = DEX关键字.length;
	    int jj = 替换文字.length;
	    for (i = 0;i < ii || i < jj;i++)
	    {
		if (DEX关键字[i].length() != 0 && !DEX关键字[i].contains(" ") && DEX关键字[i] != "" && DEX关键字[i] != "null" && DEX关键字[i] != null)
		{
		    sharedex.StringReplace(DEX关键字[i], 替换文字[i]);
		    root.sendMsg("替换Dex关键字...");
		}
	    }
	    ClassDataItem.EncodedMethod onCreate;
	    onCreate =  apkDex.getMethodByName("L" + start.replace(".", "/") + ";" + "->" + "onCreate");
	    String code = apkDex.getByteCode(onCreate);
	    if (onCreate == null || onCreate.codeItem == null || code == null)
	    {
		root.finishWithResult("获取onCreate入口失败。\n未知原因或onCreate错误为空\nonCreate=" + code);
	    }
	    else
	    {
		String in = 调用代码.replace("寄存器", "v0");
		root.sendMsg("正在添加调用代码...");
		String add =String.format("move-object/from16 v0 v%d\n" + in + "\n", (onCreate.codeItem.getRegisterCount() - 2));
		code = add + code;
		root.sendMsg("修改寄存器中...");
	    }
	    apkDex.setByteCode(code);
	    List<ClassDefItem> shareClasses =  sharedex.getClasses();
	    root.sendMsg("开始合并输出...");
	    shareClasses.addAll(apkDex.getClasses());
	    apkDex.setClasses(shareClasses);
	    root.sendMsg("正在输出保存中...");
	    apkDex.setSaveDexListener(new SaveDexListener()
		{
		    @Override
		    public void onProgress(int total, int now)
		    {
			root.sendMsg("已完成" + now + "/剩余" + total);
		    }
		});
	    apkDex.save(dex);
	}
	catch (Exception e)
	{
	    root.finishWithResult("植入代码失败：\n" + e.toString() + "\n获取onCreate入口失败。\n未知原因或onCreate错误为空\nonCreate：" + code);
	    return;
	}
    }

    private static void 全部入口(final ThreadOperation root, ZipReader zip, String 调用代码 , final String... DEX关键字 , final String... 替换文字) throws IOException, XmlPullParserException
    {
	try
	{
	    root.sendMsg("开始处理...");
	    PackageManager pm = getContext().getPackageManager();
	    final PackageInfo info = pm.getPackageArchiveInfo(zip.getFile().getAbsolutePath(), pm.GET_ACTIVITIES);
	    ActivityInfo[] as = info.activities;
	    clses = new ArrayList<String>();
	    root.sendMsg("获取程序入口...");
	    for (ActivityInfo a:as)
	    {
		if (a.name.startsWith("."))
		    clses.add(info.packageName + a.name);
		else
		    clses.add(a.name);
	    }
	    String rawXml=FormatFaUtils.sdtoString(decodedMani.getAbsolutePath());
	    String beAdded =new String(getFileAsByte("/AndroidManifes"));
	    String[] beAddeds = beAdded.split("<!--添加所需要的权限配置\\(勿删\\)-->");
	    String beAddes = beAddeds[0];
	    String beAddesd = beAddeds[1];
	    String rawXmls = rawXml.replace("</application>", beAddes + "</application>");
	    String rawXms = rawXmls.replace("</manifest>", beAddesd + "</manifest>");
	    root.sendMsg("正在植入权限...");
	    FormatFaUtils.stringtosd(rawXms, decodedMani.getAbsolutePath());
	    com.bigzhao.xml2axml.test.Main.encode(getContext(), decodedMani.getAbsolutePath(), mani.getAbsolutePath());
	    root.sendMsg("请稍候,正在处理中...");
	    DexUtils sharedex;
	    sharedex = new DexUtils(new DexFile(getFileAsByte("/plugin.dex")));
	    DexUtils apkDex ;
	    apkDex = new DexUtils(new DexFile(FileUtils.readFile(dex)));
	    root.sendMsg("处理Dex文件中...");
	    sharedex.StringReplace("启动界面", start);
	    final int i;
	    int ii = DEX关键字.length;
	    int jj = 替换文字.length;
	    for (i = 0;i < ii || i < jj;i++)
	    {
		if (DEX关键字[i].length() != 0 && !DEX关键字[i].contains(" ") && DEX关键字[i] != "" && DEX关键字[i] != "null" && DEX关键字[i] != null)
		{
		    sharedex.StringReplace(DEX关键字[i], 替换文字[i]);
		    root.sendMsg("替换Dex关键字...");
		}
	    }
	    for (String s:clses)
	    {
		ClassDataItem.EncodedMethod oncreate = apkDex.getMethodByName("L" + s.replace(".", "/") + ";->onCreate");
		String code = apkDex.getByteCode(oncreate);
		if (oncreate == null || oncreate.codeItem == null || code == null)
		{
		    root.finishWithResult("获取onCreate入口失败。\n未知原因或onCreate错误为空\nonCreate=" + code);
		    continue;
		}
		root.sendMsg("正在添加调用代码...");
		String in = 调用代码.replace("寄存器", "v0");
		String add =String.format("move-object/from16 v0 v%d\n" + in + "\n", (oncreate.codeItem.getRegisterCount() - 2));
		root.sendMsg("修改寄存器中...");
		code = add + code;
		apkDex.setByteCode(code);
	    }
	    root.sendMsg("开始合并输出...");
	    List<ClassDefItem> shareClasses =  apkDex.getClasses();
	    shareClasses.addAll(sharedex.getClasses());
	    apkDex.setClasses(shareClasses);
	    root.sendMsg("正在输出保存中...");
	    apkDex.setSaveDexListener(new SaveDexListener()
		{
		    @Override
		    public void onProgress(int total, int now)
		    {
			root.sendMsg("已完成" + now + "/剩余" + total);
		    }
		});
	    apkDex.save(dex);
	}
	catch (Exception e)
	{
	    root.finishWithResult("植入代码失败：\n" + e.toString() + "\n获取onCreate入口失败。\n未知原因或onCreate错误为空\nonCreate：" + code);
	    return;
	}
    }

    private static void 选择入口(final ThreadOperation root, final ZipReader zip, String itm, final String 调用代码 , final String... DEX关键字 , final String... 替换文字) throws IOException, XmlPullParserException
    {
	try
	{
	    String rawXml=FormatFaUtils.sdtoString(decodedMani.getAbsolutePath());
	    String beAdded =new String(getFileAsByte("/AndroidManifes"));
	    root.sendMsg("正在植入权限...");
	    String[] beAddeds = beAdded.split("<!--添加所需要的权限配置\\(勿删\\)-->");
	    String beAddes = beAddeds[0];
	    String beAddesd = beAddeds[1];
	    String rawXmls = rawXml.replace("</application>", beAddes + "</application>");
	    String rawXms = rawXmls.replace("</manifest>", beAddesd + "</manifest>");
	    FormatFaUtils.stringtosd(rawXms, decodedMani.getAbsolutePath());
	    com.bigzhao.xml2axml.test.Main.encode(getContext(), decodedMani.getAbsolutePath(), mani.getAbsolutePath());
	    root.sendMsg("请稍候,正在处理中...");
	    final DexUtils sharedex;
	    sharedex = new DexUtils(new DexFile(getFileAsByte("/plugin.dex")));
	    final DexUtils apkDex ;
	    apkDex = new DexUtils(new DexFile(FileUtils.readFile(dex)));
	    root.sendMsg("处理Dex文件中...");
	    sharedex.StringReplace("启动界面", start);
	    final int i;
	    int ii = DEX关键字.length;
	    int jj = 替换文字.length;
	    for (i = 0;i < ii || i < jj;i++)
	    {
		if (DEX关键字[i].length() != 0 && !DEX关键字[i].contains(" ") && DEX关键字[i] != "" && DEX关键字[i] != "null" && DEX关键字[i] != null)
		{
		    sharedex.StringReplace(DEX关键字[i], 替换文字[i]);
		    root.sendMsg("替换Dex关键字...");
		}
	    }
	    ClassDataItem.EncodedMethod oncreate = apkDex.getMethodByName("L" + itm.replace(".", "/") + ";->onCreate");
	    if (oncreate == null)
	    {
		root.finishWithResult("获取主入口失败\n该Apk软件的AndroidManifest.xml可能存在未知属性,加密或损坏。");
	    }
	    else
	    {
		root.sendMsg("正在添加调用代码...");
		String code = apkDex.getByteCode(oncreate);
		String in = 调用代码.replace("寄存器", "v0");
		String add =String.format("move-object/from16 v0 v%d\n" + in + "\n", (oncreate.codeItem.getRegisterCount() - 2));
		root.sendMsg("修改寄存器中...");
		code = add + code;
		apkDex.setByteCode(code);
		root.sendMsg("开始合并输出...");
		List<ClassDefItem> shareClasses =  sharedex.getClasses();
		shareClasses.addAll(apkDex.getClasses());
		apkDex.setClasses(shareClasses);
		root.sendMsg("正在输出保存中...");
		apkDex.setSaveDexListener(new SaveDexListener()
		    {
			@Override
			public void onProgress(int total, int now)
			{
			    root.sendMsg("已完成" + now + "/剩余" + total);
			}
		    });

		apkDex.save(dex);
	    }
	}
	catch (Exception e)
	{
	    root.finishWithResult("植入代码失败：\n" + e.toString() + "\n获取onCreate入口失败。\n未知原因或onCreate错误为空\nonCreate：" + code);
	    return;
	}
    }

    public static void 设置输入类型(final EditText r , final String m)
    {
	r.addTextChangedListener(new TextWatcher() {
		@Override
		public void afterTextChanged(Editable p1)
		{}
		@Override
		public void beforeTextChanged(CharSequence chars, int i, int i1, int i2)
		{}
		@Override
		public void onTextChanged(CharSequence chars, int i, int i1, int i2)
		{
		    String dc = r.getText().toString();
		    Pattern dd = Pattern.compile(m);
		    Matcher de = dd.matcher(dc);
		    String df = de.replaceAll("").trim();
		    if (!dc.equals(df))
		    {
			r.setText(df);
			r.setSelection(df.length());
		    }
		}
	    });
    }

    private static List<ClassDataItem.EncodedMethod> 搜索启动项(DexUtils dex, String id)
    {
	List<ClassDataItem.EncodedMethod> re = new ArrayList<ClassDataItem.EncodedMethod>();
	for (ClassDefItem def:dex.getClasses())
	{
	    for (ClassDataItem.EncodedMethod meth:dex.getMethods(def))
	    {
		if (meth.method.getMethodString().equals(id))
		    continue;
		if (meth.codeItem != null)
		{
		    Instruction[] instructions=meth.codeItem.getInstructions();
		    for (Instruction instruction:instructions)
		    {
			boolean is=false;
			switch (instruction.getFormat())
			{
			    case Format3rc:
			    case Format35c:
				switch (instruction.opcode.referenceType)
				{
				    case method:
					InstructionWithReference ref=(InstructionWithReference)instruction;
					MethodIdItem m =  ((MethodIdItem)ref.getReferencedItem());
					if (m.getMethodString().equals(id))
					{
					    re.add(meth);
					    is = true;}
					break;
				}
			}
			if (is)break;
		    }
		}
	    }
	}
	return re;
    }

    public static void 插件自校检(我的插件 main, Activity act)
    {
	try
	{
	    String ino = a(main.getResourse(d(KEY, "C0B1AFBB3483EF6687EC22B47FF0C540")));
	    String iou = a(main.getResourse(d(KEY, "E093C863F2845E5420B1278B9367C6B2")));
	    String str = c(KEY, ino) + "|" + c(KEY, iou);
	    InputStream key = main.getResourse(d(KEY, "C0287D298E96601146D45BF5FFB5DB6F"));
	    InputStream My = main.getResourse(d(KEY, "7D4A1F163945DE33D5C2C088BB394F4C"));
	    String aaa = new String(getFileAsByte(d(KEY, "D86CB4417788AEDEEE9685869253FFE8")));
	    if (My != null)
	    {
		if (aaa != null && aaa.length() != 0)
		{
		    InputStreamReader read = new InputStreamReader(My, "UTF-8");
		    BufferedReader bufferedReader = new BufferedReader(read);
		    String lineTxt = null;
		    String[] singleString = null;
		    while ((lineTxt = bufferedReader.readLine()) != null)
		    {
			singleString = lineTxt.split("\\|");
			d1 = singleString[0];
			d2 = singleString[1];
		    }
		    read.close();
		    if (ino != null && d1 != null && !ino.equals(d(KEY, d1)) || iou != null && d2 != null && !iou.equals(d(KEY, d2)))
		    {
			if (key != null)
			{
			    Toast.makeText(getContext(), d(KEY, "F1EE8159989ADAF7AC41E23B713663C76BBF59EFBDB6CE816164C1F3389496C6077BC12CE4E466FE64A32DC35A875BBA3B526F2B627B01EC114E0EF6DF7237D33C29206E1CC359187BAD51931B86087D841CA8D60D1FFE0A4B8CA0E1EC158EB3"), Toast.LENGTH_SHORT).show();
			    Toast.makeText(getContext(), d(KEY, "A47F41AB70B8161E8FE6DD68B36F4583F7E01DF78F332AF50F456E9DCF871041E5388DCF22C735A7C174DEF7F15D4D84305505FE25F29F4638334E7C85FE52EFDDB42E530955503C434324331CD22F87"), Toast.LENGTH_LONG).show();
			    String filePath = null;
			    boolean hasSDCard =Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
			    if (hasSDCard)
			    {
				filePath = Environment.getExternalStorageDirectory().toString() + File.separator + "md5.key";
			    }
			    else
				Toast.makeText(getContext(), d(KEY, "2F256A6AA35709F5B623A2CCD16103779E6C835106ADD297898C1C7D4FCE2AA20B8A760294CAF173E8D82F707823F349696AE634ACC93082CF4791A534A2582E"), Toast.LENGTH_LONG).show();
			    File file = new File(filePath);
			    if (!file.exists())
			    {
				File dir = new File(file.getParent());
				dir.mkdirs();
				file.createNewFile();
			    }
			    FileOutputStream outStream = new FileOutputStream(file);
			    outStream.write(str.getBytes());
			    outStream.close();
			}
			else
			{
			    act.finish();
			}
		    }
		    else if (d1 == null || d2 == null || d1.length() == 0 || d2.length() == 0)
		    {
			if (key != null)
			{
			    Toast.makeText(getContext(), d(KEY, "612CEA6B8396B236914206A556CB7CA70D8DB17D5C7416BB45A9CA37A3AD4C8F3AB8F99C824ED41C039B9D4BDCFC6A94AE74FE3B7BE55D43297151938662C20D0F6FA0D6F7B5148B7C407CC39FBD4CF4696AE634ACC93082CF4791A534A2582E"), Toast.LENGTH_SHORT).show();
			    Toast.makeText(getContext(), d(KEY, "A47F41AB70B8161E8FE6DD68B36F4583F7E01DF78F332AF50F456E9DCF871041E5388DCF22C735A7C174DEF7F15D4D84305505FE25F29F4638334E7C85FE52EFDDB42E530955503C434324331CD22F87"), Toast.LENGTH_LONG).show();
			    String filePath = null;
			    boolean hasSDCard =Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
			    if (hasSDCard)
			    {
				filePath = Environment.getExternalStorageDirectory().toString() + File.separator + "md5.key";
			    }
			    else
				Toast.makeText(getContext(), d(KEY, "2F256A6AA35709F5B623A2CCD16103779E6C835106ADD297898C1C7D4FCE2AA20B8A760294CAF173E8D82F707823F349696AE634ACC93082CF4791A534A2582E"), Toast.LENGTH_LONG).show();
			    File file = new File(filePath);
			    if (!file.exists())
			    {
				File dir = new File(file.getParent());
				dir.mkdirs();
				file.createNewFile();
			    }
			    FileOutputStream outStream = new FileOutputStream(file);
			    outStream.write(str.getBytes());
			    outStream.close();
			}
			else
			{
			    act.finish();
			}
		    }
		    else if (ino == null || iou == null || ino.length() == 0 || iou.length() == 0)
		    {
			if (key != null)
			{
			    Toast.makeText(getContext(), d(KEY, "BCFC81F8AA0DC2E4ADF871F52E8C2747DF532529E376F8FF27531DE37CB9CC0EFEB3A5150B1EFC98CE4D640B186015B722F8989CD1D57114F26826C0FB6004EE9C17DF1BC0FCE1AE330FF56AF658D1DC8C49DC34BBB5F71BE65030C4B18DD26A"), Toast.LENGTH_LONG).show();
			}
			else
			{
			    act.finish();
			}
		    }
		    else
		    {
			if (key != null)
			{
			    Toast.makeText(getContext(), d(KEY, "2C27735829B90D19762344468F3832062654D8C97C8CED586299B46A7713891C1A734EE3853A31BD8C45F69713F37C501CFBA607F65FCFF5126BC6387A98DA4B5862E7237D8A0FC3B3D6EB3799EA60748525C90C02F7D026BC05C97554B57952"), Toast.LENGTH_LONG).show();
			}
		    }
		}
		else
		{
		    if (key != null)
		    {
			Toast.makeText(getContext(), d(KEY, "42782CA27AA27BDD95CE34A22F8F73FB8B9156F799A191A8BD7691357B850E75E5B899B70FC019FCC227B3481DA5B7B8253CE8B21C1FF873059F83B2528AE3B9890471CE092391FFE25A6F620701584F"), Toast.LENGTH_SHORT).show();
			Toast.makeText(getContext(), d(KEY, "A47F41AB70B8161E8FE6DD68B36F4583F7E01DF78F332AF50F456E9DCF871041E5388DCF22C735A7C174DEF7F15D4D84305505FE25F29F4638334E7C85FE52EFDDB42E530955503C434324331CD22F87"), Toast.LENGTH_LONG).show();
			String filePath = null;
			boolean hasSDCard =Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
			if (hasSDCard)
			{
			    filePath = Environment.getExternalStorageDirectory().toString() + File.separator + "md5.key";
			}
			else
			    Toast.makeText(getContext(), d(KEY, "2F256A6AA35709F5B623A2CCD16103779E6C835106ADD297898C1C7D4FCE2AA20B8A760294CAF173E8D82F707823F349696AE634ACC93082CF4791A534A2582E"), Toast.LENGTH_LONG).show();
			File file = new File(filePath);
			if (!file.exists())
			{
			    File dir = new File(file.getParent());
			    dir.mkdirs();
			    file.createNewFile();
			}
			FileOutputStream outStream = new FileOutputStream(file);
			outStream.write(str.getBytes());
			outStream.close();
		    }
		    else
		    {
			act.finish();
		    }
		}
	    }
	    else
	    {
		if (key != null)
		{
		    Toast.makeText(getContext(), d(KEY, "7DDCB1E86ACD00F1A8E776A0934B5DAEDFAF691F352A2B9A717F2A1480D182ACCF9D9F7D30FF25125C947E0A89F81C5FAE74FE3B7BE55D43297151938662C20D0F6FA0D6F7B5148B7C407CC39FBD4CF4696AE634ACC93082CF4791A534A2582E"), Toast.LENGTH_SHORT).show();
		    Toast.makeText(getContext(), d(KEY, "A47F41AB70B8161E8FE6DD68B36F4583F7E01DF78F332AF50F456E9DCF871041E5388DCF22C735A7C174DEF7F15D4D84305505FE25F29F4638334E7C85FE52EFDDB42E530955503C434324331CD22F87"), Toast.LENGTH_LONG).show();
		    String filePath = null;
		    boolean hasSDCard =Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED);
		    if (hasSDCard)
		    {
			filePath = Environment.getExternalStorageDirectory().toString() + File.separator + "md5.key";
		    }
		    else
			Toast.makeText(getContext(), d(KEY, "2F256A6AA35709F5B623A2CCD16103779E6C835106ADD297898C1C7D4FCE2AA20B8A760294CAF173E8D82F707823F349696AE634ACC93082CF4791A534A2582E"), Toast.LENGTH_LONG).show();
		    File file = new File(filePath);
		    if (!file.exists())
		    {
			File dir = new File(file.getParent());
			dir.mkdirs();
			file.createNewFile();
		    }
		    FileOutputStream outStream = new FileOutputStream(file);
		    outStream.write(str.getBytes());
		    outStream.close();
		}
		else
		{
		    act.finish();
		}
	    }
	}
	catch (IOException e)
	{}
    }

    public static String 获取应用名称(String Apk路径)
    {
        if (Apk路径 != null)
	{
	    PackageManager pm = getContext().getPackageManager();
	    PackageInfo info = pm.getPackageArchiveInfo(Apk路径, PackageManager.GET_ACTIVITIES);
	    if (pm != null && info != null)
	    {
		ApplicationInfo appInfo = info.applicationInfo;
		appInfo.sourceDir = Apk路径;
		appInfo.publicSourceDir = Apk路径;
		return appInfo.loadLabel(pm).toString();
	    }
	}
        return null;
    }

    public static void 安装APK(Activity activity , File Apk路径)
    {
        Intent intent = new Intent();
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        intent.setAction(Intent.ACTION_VIEW);
        intent.setDataAndType(Uri.fromFile(Apk路径), "application/vnd.android.package-archive");
        activity.startActivity(intent);
    }

    public static void 卸载指定应用(Activity activity , String 包名)
    {
        Intent intent = new Intent(Intent.ACTION_DELETE);
        Uri packageURI = Uri.parse("package:" + 包名);
        intent.setData(packageURI);
        activity.startActivity(intent);
    }

    public static String 获取版本号(String Apk路径)
    {
        if (Apk路径 != null)
	{
	    PackageManager pm = getContext().getPackageManager();
	    PackageInfo info = pm.getPackageArchiveInfo(Apk路径, PackageManager.GET_ACTIVITIES);
	    if (pm != null && info != null)
	    {
		ApplicationInfo appInfo = info.applicationInfo;
		appInfo.sourceDir = Apk路径;
		appInfo.publicSourceDir = Apk路径;
		return info.versionName == null ?"0": info.versionName;
	    }
	}
        return null;
    }

    public static Drawable 获取应用图标(String Apk路径)
    {
        if (Apk路径 != null)
	{
	    PackageManager pm = getContext().getPackageManager();
	    PackageInfo info = pm.getPackageArchiveInfo(Apk路径, PackageManager.GET_ACTIVITIES);
	    if (pm != null && info != null)
	    {
		ApplicationInfo appInfo = info.applicationInfo;
		appInfo.sourceDir = Apk路径;
		appInfo.publicSourceDir = Apk路径;
		return appInfo.loadIcon(pm);
	    }
	}
        return null;
    }

    public static boolean 判断是否安装(String 包名)
    {
        boolean installed = false;
        if (TextUtils.isEmpty(包名))
	{
            return false;
        }
        List<ApplicationInfo> installedApplications = getContext().getPackageManager().getInstalledApplications(0);
        for (ApplicationInfo in : installedApplications)
	{
            if (包名.equals(in.packageName))
	    {
                installed = true;
                break;
            }
	    else
	    {
                installed = false;
            }
        }
        return installed;
    }

    public static void 打开指定应用(String 包名)
    {
	PackageManager packageManager = getContext().getPackageManager(); 
	Intent intent=new Intent(); 
	intent = packageManager.getLaunchIntentForPackage(包名); 
	getContext().startActivity(intent);
    }

    public static String 获取应用包名(String Apk路径)
    {
	if (Apk路径 != null)
	{
	    PackageManager pm = getContext().getPackageManager();
	    PackageInfo info = pm.getPackageArchiveInfo(Apk路径, PackageManager.GET_ACTIVITIES);
	    if (pm != null && info != null)
	    {
		return info.packageName;
	    }
	}
	return null;
    }

    public static String 获取系统时间()
    {
        Calendar cal = Calendar.getInstance();
        cal.setTimeInMillis(System.currentTimeMillis());
        return cal.get(Calendar.HOUR_OF_DAY) + ":" + cal.get(Calendar.MINUTE) + ":" + cal.get(Calendar.SECOND);
    }

    public static String 获取系统日期()
    {
        return new SimpleDateFormat("yyyyMMdd").format(System.currentTimeMillis());
    }

    public static String 获取文件大小(String filePath)
    {
        File file = new File(filePath);
        long blockSize = 0;
        try
	{
            if (file.isDirectory())
	    {
                blockSize = getFileSizes(file);
            }
	    else
	    {
                blockSize = getFileSize(file);
            }
        }
	catch (Exception e)
	{
            e.printStackTrace();
        }
        return FormetFileSize(blockSize);
    }

    private static long getFileSize(File file) throws Exception
    {
        long size = 0;
        if (file.exists())
	{
            FileInputStream fis = null;
            fis = new FileInputStream(file);
            size = fis.available();
        }
	else
	{
            file.createNewFile();
        }
        return size;
    }

    private static long getFileSizes(File f) throws Exception
    {
        long size = 0;
        File flist[] = f.listFiles();
        for (int i = 0; i < flist.length; i++)
	{
            if (flist[i].isDirectory())
	    {
                size = size + getFileSizes(flist[i]);
            }
	    else
	    {
                size = size + getFileSize(flist[i]);
            }
        }
        return size;
    }

    private static String FormetFileSize(long fileS)
    {
        DecimalFormat df = new DecimalFormat("#.00");
        String fileSizeString = "";
        String wrongSize = "0B";
        if (fileS == 0)
	{
            return wrongSize;
        }
        if (fileS < 1024)
	{
            fileSizeString = df.format((double) fileS) + "B";
        }
	else if (fileS < 1048576)
	{
            fileSizeString = df.format((double) fileS / 1024) + "KB";
        }
	else if (fileS < 1073741824)
	{
            fileSizeString = df.format((double) fileS / 1048576) + "MB";
        }
	else
	{
            fileSizeString = df.format((double) fileS / 1073741824) + "GB";
        }
        return fileSizeString;
    }

    public static String 获取应用签名(String Apk路径)
    {
	if (Apk路径 != null)
	{
	    PackageManager pm = getContext().getPackageManager();
	    PackageInfo info = pm.getPackageArchiveInfo(Apk路径, PackageManager.GET_SIGNATURES);
	    if (pm != null && info != null)
	    {
		return info.signatures[0].hashCode() + "";
	    }
	}
	return null;
    }

    public static String 获取应用权限(String Apk路径)
    {
	if (Apk路径 != null)
	{
	    PackageManager pm = getContext().getPackageManager();
	    PackageInfo info = pm.getPackageArchiveInfo(Apk路径, PackageManager.GET_PERMISSIONS);
	    StringBuffer sb = new StringBuffer();
	    if (pm != null && info != null)
	    {
		String[] perms = info.requestedPermissions;
		if (perms != null)
		{
		    for (String permName: perms)
		    {
			if (permName != null)
			{
			    sb.append(permName).append('\n');
			}
		    }
		}
		return sb.toString();
	    }
	}
	return null;
    }

    public static String 获取应用Activity()
    {
	if (ite != null)
	{
	    StringBuffer sb = new StringBuffer();
	    for (String activity:ite)
	    {
		if (activity != null)
		{
		    sb.append(activity).append('\n');
		}
	    }
	    return sb.toString();
	}
	return null;
    }
}
