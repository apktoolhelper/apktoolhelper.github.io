package kpa.plugin.library;
import android.content.*;
import android.util.*;
import android.view.*;
import android.widget.*;

public class 输入框 extends EditText
{
    public 输入框(Context context)
    {
        super(context);
    }

    public 输入框(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    public 输入框(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }

    public void 设置文本内容(String 文本内容)
    {
	setText(文本内容);
    }
    public void 设置提示文本(String 文本内容)
    {
	setHint(文本内容);
    }

    public String 获取输入框的内容()
    {
	return getText().toString();
    }

    public void 设置文字颜色(int 颜色值)
    {
	setTextColor(颜色值);
    }
    public void 设置宽度(int 高度)
    {
	getLayoutParams().width = 高度;
	requestLayout();
    }

    public void 设置高度(int 宽度)
    {
	getLayoutParams().height = 宽度;
	requestLayout();
    }

    public void 设置显示状态(int 隐藏或显示)
    {
	setVisibility(隐藏或显示);
    }
    public void 设置字体大小(int 大小值)
    {
	setTextSize(大小值);
    }

    public void 设置行数(int 行数)
    {
	setLines(行数);
    }

    public void 设置最小行数(int 行数)
    {
	setMinLines(行数);
    }

    public void 设置最大行数(int 行数)
    {
	setMaxLines(行数);
    }

    public void 设置是否允许编辑(boolean 布尔值)
    {
	setFocusableInTouchMode(布尔值);
	setFocusable(布尔值);
	requestFocus();
    }


    public void 设置提示文本颜色(int 颜色值)
    {
	setHintTextColor(颜色值);
    }

    public void 限制输入允许类型(int 输入类型)
    {
	setInputType(输入类型);
    }

}
