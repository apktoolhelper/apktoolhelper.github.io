package kpa.plugin.library;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.util.DisplayMetrics;
import android.util.TypedValue;
import android.view.MotionEvent;
import android.view.View;

class AlphaView extends View {
	private final Paint mPaint;
	private float tx;
	private OnAlphaChangedListener listener;
	private final AlphaPatternDrawable alphaPatternDrawable;
	private Shader s;
	interface OnAlphaChangedListener {
		void OnAlphaChanged(float alpha);
	}
	AlphaView(Context c) {
		this(c, null);
	}
	AlphaView(Context c, AttributeSet a) {
		super(c, a);
		mPaint = new Paint();
		alphaPatternDrawable = new AlphaPatternDrawable(dpToPx(c, 4));
		tx = 0;
	}
	void setOnAlphaChangedListener(OnAlphaChangedListener listener) {
		this.listener = listener;
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		float m = ColorPickerLayout.margin;
		s = new LinearGradient(m, m, w - m, m, 0xff000000, 0, Shader.TileMode.CLAMP);
		int mm = (int)m;
		alphaPatternDrawable.setBounds(mm, mm, w - mm, h - mm);
		super.onSizeChanged(w, h, oldw, oldh);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		float m = ColorPickerLayout.margin;
		if (tx == 0)
			tx = m;
		float w = getWidth() - m;
		float h = getHeight() - m;
		alphaPatternDrawable.draw(canvas);
		mPaint.setShader(s);
		canvas.drawRect(m, m, w, h, mPaint);
		canvas.drawRect(tx - ColorPickerLayout.size, m, tx + ColorPickerLayout.size, h, ColorPickerLayout.label);
	}

	void setColor(float h) {
		float[] hsv = {h,1f,1f};
		int color = Color.HSVToColor(hsv);
		int color1 = Color.HSVToColor(0, hsv);
		float m = ColorPickerLayout.margin;
		s = new LinearGradient(m, m, getWidth() - m, m, color, color1, Shader.TileMode.MIRROR);
		invalidate();
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		tx = event.getX();
		float m = ColorPickerLayout.margin;
		float w = getWidth() - m;
		if (tx < m)
			tx = m;
		if (tx > w)
			tx = w;
		float p = (tx - m) / (w - m);
		if (listener != null)
			listener.OnAlphaChanged((1 - p) * 255);
		invalidate();
		return true;
	}
	void setA(float alpha) {
		float p = alpha / 255f;
		float m = ColorPickerLayout.margin;
		float w = getWidth() - m * 2;
		tx = m + w * (1 - p);
		invalidate();
	}
	static int dpToPx(Context c, float dipValue) {
		DisplayMetrics metrics = c.getResources().getDisplayMetrics();
		float val = TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, dipValue, metrics);
		int res = (int) (val + 0.5); // Round
		// Ensure at least 1 pixel if val was > 0
		return res == 0 && val > 0 ? 1 : res;
	}
}
