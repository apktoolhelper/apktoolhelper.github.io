package kpa.plugin.library;

import FormatFa.ApktoolHelper.View.*;

public class 启动新线程 implements ThreadOperation.OnStartListener
{
    @Override
    public void start(ThreadOperation root)
    {
	线程开始(root);
    }

    @Override
    public void finish()
    {
	线程结束();
    }

    public void 线程开始(ThreadOperation root)
    {}
    public void 线程结束()
    {}
}
