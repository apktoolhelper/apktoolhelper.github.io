package kpa.plugin.library;
import android.content.*;
import android.util.*;
import android.view.*;
import android.widget.*;

public class 滑动布局 extends ScrollView
{
    public 滑动布局(Context context)
    {
        super(context);

    }

    public 滑动布局(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    public 滑动布局(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }
    public void 设置背景颜色(int 颜色值)
    {
	this.setBackgroundColor(颜色值);
    }

    public void 设置布局内边距(int 左, int 上, int 右, int 下)
    {
	this.setPadding(左, 上, 右, 下);
    }

    public View 获取布局(Context context, int id)
    {
	LayoutInflater inflater=(LayoutInflater)context. getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	View view=inflater.inflate(id, null);
	return view;
    }
    public View 反复添加布局(Context context, int id)
    {
	LayoutInflater inflater=(LayoutInflater)context. getSystemService(Context.LAYOUT_INFLATER_SERVICE);
	View view=inflater.inflate(id, null);
	return view;
    }
    public void 添加布局(View view)
    {
	addView(view);
    }

}
