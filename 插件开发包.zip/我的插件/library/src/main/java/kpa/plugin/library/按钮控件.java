package kpa.plugin.library;
import android.content.*;
import android.graphics.*;
import android.util.*;
import android.view.*;
import android.widget.*;

public class 按钮控件 extends Button
{

    public 按钮控件(Context context)
    {
        super(context);

    }

    public 按钮控件(Context context, AttributeSet attrs)
    {
        super(context, attrs);
    }

    public 按钮控件(Context context, AttributeSet attrs, int defStyle)
    {
        super(context, attrs, defStyle);
    }

    public void setOnClickListener(Object onClick)
    {
	// TODO: Implement this method
    }



    public void 设置文本内容(String 文本内容)
    {
	setText(文本内容);
    }
    public String 获取按钮文本内容()
    {
	return getText().toString();
    }
    public void 设置文字颜色(int 颜色值)
    {
	setTextColor(颜色值);
    }
    public void 设置宽度(int 高度)
    {
	getLayoutParams().width = 高度;
	requestLayout();
    }

    public void 设置高度(int 宽度)
    {
	getLayoutParams().height = 宽度;
	requestLayout();
    }

    public void 设置显示状态(int 隐藏或显示)
    {
	setVisibility(隐藏或显示);
    }


    public void 设置字体大小(int 大小值)
    {
	setTextSize(大小值);
    }
    
    public void 设置点击事件(OnClickListener 点击事件)
    {
	setOnClickListener(点击事件);
    }

}
