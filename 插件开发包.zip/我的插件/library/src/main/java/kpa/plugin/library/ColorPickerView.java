package kpa.plugin.library;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.ComposeShader;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.util.AttributeSet;
import android.view.View;
import android.graphics.PorterDuffXfermode;
import android.graphics.Shader;
import android.view.MotionEvent;

class ColorPickerView extends View {
	private final Paint mPaint;
	private final Paint label;
	private final float[] hsv;
	private Shader s1,s2;
	private float tx,ty,h;
	private OnSVChangedListener listener;
	interface OnSVChangedListener {
		void onSVChanged(float s, float v);
	}
	ColorPickerView(Context c) {
		this(c, null);
	}
	ColorPickerView(Context c, AttributeSet a) {
		super(c, a);
		mPaint = new Paint();
		mPaint.setXfermode(new PorterDuffXfermode(PorterDuff.Mode.MULTIPLY));
		label = new Paint();
		label.setStrokeWidth(ColorPickerLayout.size);
		label.setStyle(Paint.Style.STROKE);
		label.setAntiAlias(true);
		hsv = new float[3];
		tx = 0;
		ty = 0;
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		float m=ColorPickerLayout.margin;
		if (tx == 0) {
			tx = m;
			ty = m;
		}
		float w = getWidth() - m;
		float h = getHeight() - m;
		mPaint.setShader(s1);
		canvas.drawRect(m, m, w, h, mPaint);
		mPaint.setShader(s2);
		canvas.drawRect(m, m, w, h, mPaint);
		canvas.drawCircle(tx, ty, 10, label);
	}

	void setOnSVChangedListener(OnSVChangedListener l) {
		listener = l;
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		float m = ColorPickerLayout.margin;
		s1 = new LinearGradient(m, m, m, h - m, 0xffffffff, 0xff000000, LinearGradient.TileMode.CLAMP);
		s2 = new LinearGradient(m, m, w - m, m, 0xffffffff, 0xff000000, LinearGradient.TileMode.CLAMP);
		super.onSizeChanged(w, h, oldw, oldh);
	}
	void setSV(float s, float v) {
		float m = ColorPickerLayout.margin;
		float w = getWidth() - m * 2;
		float h = getHeight() - m * 2;
		v=1f-v;
		tx = m + w * s;
		ty = m + h * v;
		int c = Color.HSVToColor(new float[]{h,0.5f,v});
		label.setColor(c);
		invalidate();
	}
	void setColor(float h) {
		this.h = h;
		float m = ColorPickerLayout.margin;
		int rgb = Color.HSVToColor(new float[]{h,1f,1f});
		float w=getWidth() - m;
		s2 = new LinearGradient(m, m, w, m, 0xffffffff, rgb, LinearGradient.TileMode.CLAMP);
		invalidate();
	}

	@Override
	public boolean onTouchEvent(MotionEvent event) {
		tx = event.getX();
		ty = event.getY();
		float m = ColorPickerLayout.margin;
		float w = getWidth() - m;
		if (tx < m)
			tx = m;
		if (tx > w)
			tx = w;
		float s = (tx - m) / (w - m);
		float h=getHeight() - m;
		if (ty < m)
			ty = m;
		if (ty > h)
			ty = h;
		float v = (ty - m) / (h - m);
		int c = Color.HSVToColor(new float[]{h,0.5f,v});
		label.setColor(c);
		v = 1f - v;
		if (listener != null)
			listener.onSVChanged(s, v);
		invalidate();
		return true;
	}

}
