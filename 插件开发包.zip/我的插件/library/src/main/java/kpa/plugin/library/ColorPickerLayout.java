package kpa.plugin.library;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.view.Gravity;
import android.widget.*;

public class ColorPickerLayout extends ViewGroup
implements ColorView.OnColorChangedListener,AlphaView.OnAlphaChangedListener,
ColorPickerView.OnSVChangedListener
{
    private final ColorPickerView pickerView;
    private final ColorView colorView;
    private final AlphaView alphaView;
    private float h,s,v;
    private int alpha;
    private int initColor;
    public ColorPickerLayout(Context c)
    {
	this(c, null);
    }
    public ColorPickerLayout(Context c, AttributeSet a)
    {
	super(c, a);
	s = 1f;
	v = 1f;
	alpha = 255;
	pickerView = new ColorPickerView(c, a);
	colorView = new ColorView(c, a);
	alphaView = new AlphaView(c, a);
	colorView.setOnColorChangedListener(this);
	alphaView.setOnAlphaChangedListener(this);
	pickerView.setOnSVChangedListener(this);
	addView(pickerView);
	addView(colorView);
	addView(alphaView);
	initColor = 0xffffffff;
    }

    @Override
    protected void onLayout(boolean p1, int l, int t, int r, int b)
    {
	int w = r - l;
	int h = b - t;
	w = Math.min(w, h);
	int w1 = w / 20;
	margin = w1 / 3;
	int m = margin;
	int w17=w1 * 17;
	int w18=w1 * 18;
	int w19=w1 * 19;
	pickerView.layout(l + w1 - m, //左
			  t + w1 - m, //上
			  l + w17 + m, //右
			  t + w17 + m);//下
	colorView.layout(l + w18 - m, //左
			 t + w1 - m, //上
			 l + w19 + m,//右
			 t + w17 + m);//下
	alphaView.layout(l + w1 - m, //左
			 t + w18 - m, //上
			 l + w19 + m, //右
			 t + w19 + m);//下
	alpha = Color.alpha(initColor);
	int red=Color.red(initColor);
	int green=Color.green(initColor);
	int blue=Color.blue(initColor);
	float[] hsv = new float[3];
	Color.RGBToHSV(red, green, blue, hsv);
	this.h = hsv[0];
	s = hsv[1];
	v = hsv[2];
	onColorChanged(this.h);
	colorView.setH(this.h);
	pickerView.setSV(s, v);
	alphaView.setA(alpha);
    }

    @Override
    public void onColorChanged(float h)
    {
	this.h = h;
	pickerView.setColor(h);
	alphaView.setColor(h);
    }

    @Override
    public void OnAlphaChanged(float alpha)
    {
	this.alpha = (int)alpha;
    }
    public void setColor(int color)
    {
	initColor = color;
    }
    @Override
    public void onSVChanged(float s, float v)
    {
	this.s = s;
	this.v = v;
    }

    @Override
    protected void onMeasure(int widthMeasureSpec, int heightMeasureSpec)
    {
	int widthAllowed = MeasureSpec.getSize(widthMeasureSpec) - getPaddingLeft() - getPaddingRight();
	int heightAllowed =
	    MeasureSpec.getSize(heightMeasureSpec) - getPaddingBottom() - getPaddingTop();
	int w=Math.min(widthAllowed, heightAllowed);
	int h=w + w / 10;
	setMeasuredDimension(w, h);
    }

    public int getColor()
    {
	return Color.HSVToColor(alpha, new float[]{h,s,v});
    }

    public static final Paint label;
    public static final int size = 4;
    public static int margin;
    static{
	label = new Paint();
	label.setColor(0xff000000);
	label.setStrokeWidth(size);
	label.setStyle(Paint.Style.STROKE);
	label.setAntiAlias(true);
    }
}
