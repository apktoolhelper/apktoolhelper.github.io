package kpa.plugin.library;
import android.view.*;
import android.view.View.*;

public abstract class 设置事件 implements OnClickListener
{
    @Override
    public void onClick(View v)
    {
	点击事件();
    }

    public void 点击事件()
    {

    }
}
