package kpa.plugin.library;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.LinearGradient;
import android.graphics.Paint;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

class ColorView extends View {
	private final Paint mPaint;
	private int[] mCircleColors;
	private float ty;
	private OnColorChangedListener listener;
	interface OnColorChangedListener {
		void onColorChanged(float color);
	}
	ColorView(Context c) {
		this(c, null);
	}
	ColorView(Context c, AttributeSet a) {
		super(c, a);
		mPaint = new Paint(Paint.ANTI_ALIAS_FLAG);  
		ty = 0;
		listener = null;
	}

	@Override
	protected void onSizeChanged(int w, int h, int oldw, int oldh) {
		mCircleColors = new int[h];
		float hh = 0f;
		float ss=360f / h;
		for (int i=0;i < h;i++) {
			mCircleColors[i] = Color.HSVToColor(new float[]{hh, 1f, 1f});
			hh += ss;
		}
		Shader s=new LinearGradient(0, 0, 0, h, mCircleColors, null, Shader.TileMode.MIRROR);
		mPaint.setShader(s);
		super.onSizeChanged(w, h, oldw, oldh);
	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		float m = ColorPickerLayout.margin;
		float w = getWidth() - m;
		float h = getHeight() - m;
		if (ty == 0)
			ty = m;
		canvas.drawRect(m, m, w, h, mPaint);
		canvas.drawRect(m, ty - ColorPickerLayout.size, w, ty + ColorPickerLayout.size, ColorPickerLayout.label);
	}
	void setOnColorChangedListener(OnColorChangedListener listener) {
		this.listener = listener;
	}
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		ty = event.getY();
		float m = ColorPickerLayout.margin;
		float h=getHeight() - m;
		if (ty < m)
			ty = m;
		if (ty > h)
			ty = h;
		float p = (ty - m) / (h - m);
		if (listener != null)
			listener.onColorChanged(p * 360f);
		invalidate();
		return true;
	}
	void setH(float h) {
		float m = ColorPickerLayout.margin;
		float hh = getHeight() - m * 2;
		ty = m + hh * (h/360f);
		invalidate();
	}
}
